CreateObject("WScript.Shell").Run "cmd /c npm start", 0, False
