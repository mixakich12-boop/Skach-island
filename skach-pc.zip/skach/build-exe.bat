@echo off
chcp 65001 >nul
title Сборка Skach
cd /d "%~dp0"
where node >nul 2>nul || (echo Сначала установите Node.js: https://nodejs.org & pause & exit /b)
call npm install || (echo Ошибка npm install & pause & exit /b)
call npm run dist || (echo Ошибка сборки. Запустите файл от имени администратора & pause & exit /b)
echo Готово: установщик и portable-версия в папке dist
start "" dist
pause
