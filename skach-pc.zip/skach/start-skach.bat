@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Сначала установите Node.js: https://nodejs.org & pause & exit /b)
if not exist node_modules (call npm install || (echo Ошибка npm install & pause & exit /b))
start "" wscript //nologo run-hidden.vbs
