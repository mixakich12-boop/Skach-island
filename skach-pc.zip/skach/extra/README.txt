Положите сюда PresentMon.exe (https://github.com/GameTechDev/PresentMon/releases), чтобы Skach показывал FPS игр.
