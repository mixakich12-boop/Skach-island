const { contextBridge, ipcRenderer: i } = require('electron');
const v = n => (...a) => i.invoke(n, ...a);
contextBridge.exposeInMainWorld('sk', {
  media: v('media'), now: v('now'), lyrics: v('lyrics'), stats: v('stats'), get: v('get'), set: v('set'), size: v('size'), quit: v('quit'),
  weather: v('weather'), clips: v('clips'), clipCopy: v('clipCopy'), clipDel: v('clipDel'), clipPin: v('clipPin'), clipClear: v('clipClear'),
  sys: v('sys'), shortcut: v('shortcut'), fpsState: v('fpsState'), fpsInstall: v('fpsInstall'), asAdmin: v('asAdmin'), resetPos: v('resetPos'), open: v('open'), ignore: v('ignore'),
  wAdd: v('wAdd'), wPreset: v('wPreset'), wClear: v('wClear'), memScan: v('memScan'), memKill: v('memKill'), memTrim: v('memTrim'),
  dragStart: () => i.send('dragStart'), dragMove: (x, y) => i.send('dragMove', x, y), dragEnd: () => i.send('dragEnd'), wSave: l => i.send('wSave', l),
  onToggle: f => i.on('toggle', f), onBlur: f => i.on('blur', f), onWcfg: f => i.on('wcfg', (_, c) => f(c))
});
