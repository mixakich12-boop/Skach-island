const { app, BrowserWindow, ipcMain, screen, globalShortcut, Tray, Menu, nativeImage, session, desktopCapturer, clipboard, shell } = require('electron');
const { spawn, execFile } = require('child_process');
app.disableHardwareAcceleration();
app.commandLine.appendSwitch('enable-low-end-device-mode');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion,SpareRendererForSitePerProcess');
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=96');
app.commandLine.appendSwitch('renderer-process-limit', '1');
const os = require('os'), fs = require('fs'), path = require('path');
const DEF = { theme: 'dark', accent: '#7a5cff', opacity: 1, pos: 'top', autostart: false, tint: true, scale: .9, top: true, fps: true, cx: null, cy: null, widgets: [], wtop: false, whide: false, aiSite: 'chatgpt', city: '', note: '' };
let cfg = { ...DEF }, win, tray, big = false;
app.setAppUserModelId('app.skach');
if (!app.requestSingleInstanceLock()) app.exit(0);
app.on('second-instance', () => win && win.webContents.send('toggle'));
const cp = () => path.join(app.getPath('userData'), 'config.json');
let saveT; const saveNow = () => { try { fs.writeFileSync(cp(), JSON.stringify(cfg)); } catch {} };
const save = () => { clearTimeout(saveT); saveT = setTimeout(saveNow, 300); };
app.on('before-quit', saveNow);
function place() {
  const w = big ? 720 : 440, h = big ? 480 : 48;
  let a = screen.getPrimaryDisplay().workArea, x, y;
  if (cfg.cx != null) {
    a = screen.getDisplayNearestPoint({ x: Math.round(cfg.cx), y: Math.round(cfg.cy) }).workArea;
    x = Math.min(Math.max(Math.round(cfg.cx - w / 2), a.x), a.x + a.width - w); y = Math.min(Math.max(Math.round(cfg.cy), a.y), a.y + a.height - h);
  } else { x = Math.round(a.x + (a.width - w) / 2); y = cfg.pos === 'top' ? a.y + 6 : a.y + a.height - h - 6; }
  win.setBounds({ x, y, width: w, height: h });
}
// ---- музыка в системе: медиаклавиши Windows / playerctl на Linux
const PS = c => new Promise(r => execFile('powershell', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', c], { windowsHide: true, timeout: 6000 }, (e, o) => r(o || '')));
const KEY = { play: 179, next: 176, prev: 177, vup: 175, vdn: 174, mute: 173 };
ipcMain.handle('media', async (_, a) => {
  if (!KEY[a]) return;
  if (process.platform === 'win32') await PS(`Add-Type -MemberDefinition '[DllImport("user32.dll")]public static extern void keybd_event(byte b,byte s,int f,int e);' -Name K -Namespace W; [W.K]::keybd_event(${KEY[a]},0,0,0); [W.K]::keybd_event(${KEY[a]},0,2,0)`);
  else if (process.platform === 'linux' && ['play', 'next', 'prev'].includes(a)) execFile('playerctl', [{ play: 'play-pause', next: 'next', prev: 'previous' }[a]], () => {});
});
// ---- что играет: Windows SMTC (любой плеер) через один постоянный процесс PowerShell
const SMTC = `
[Console]::OutputEncoding=[Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$at=([System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1'})[0]
function Aw($t,$r){$n=$at.MakeGenericMethod($r).Invoke($null,@($t));$n.Wait(-1)|Out-Null;$n.Result}
$null=[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]
$null=[Windows.Storage.Streams.IRandomAccessStreamWithContentType,Windows.Storage.Streams,ContentType=WindowsRuntime]
$m=Aw ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
Add-Type -Namespace W -Name U -MemberDefinition '[DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow();[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);[DllImport("user32.dll")]public static extern bool GetWindowRect(IntPtr h,int[] r);[DllImport("user32.dll")]public static extern IntPtr MonitorFromWindow(IntPtr h,uint f);[DllImport("user32.dll")]public static extern bool GetMonitorInfo(IntPtr m,int[] i);'
function Fg{try{$h=[W.U]::GetForegroundWindow();$p=[uint32]0;$null=[W.U]::GetWindowThreadProcessId($h,[ref]$p);$r=New-Object int[] 4;$null=[W.U]::GetWindowRect($h,$r);$mi=New-Object int[] 10;$mi[0]=40;$null=[W.U]::GetMonitorInfo([W.U]::MonitorFromWindow($h,2),$mi);[pscustomobject]@{n=(Get-Process -Id $p).ProcessName;f=($r[0] -le $mi[1]+1 -and $r[1] -le $mi[2]+1 -and $r[2] -ge $mi[3]-1 -and $r[3] -ge $mi[4]-1)}}catch{[pscustomobject]@{n='';f=$false}}}
$last=''
while($true){try{
 $f=Fg;$s=$m.GetCurrentSession()
 if($s){
  $p=Aw ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
  $i=$s.GetPlaybackInfo();$t=$s.GetTimelineProperties()
  $k=$p.Title+'|'+$p.Artist;$th=''
  if($k -ne $last){$last=$k;try{$st=Aw ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType]);$ms=New-Object IO.MemoryStream;[System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st).CopyTo($ms);$th=[Convert]::ToBase64String($ms.ToArray())}catch{}}
  [pscustomobject]@{title=$p.Title;artist=$p.Artist;album=$p.AlbumTitle;playing=([int]$i.PlaybackStatus -eq 4);pos=$t.Position.TotalSeconds;dur=$t.EndTime.TotalSeconds;app=$s.SourceAppUserModelId;cover=$th;fg=$f.n;full=$f.f}|ConvertTo-Json -Compress
 } else {[pscustomobject]@{fg=$f.n;full=$f.f}|ConvertTo-Json -Compress}
}catch{'{}'}
Start-Sleep -Milliseconds 1000}`;
let np = {}, sentKey = '', nowP, fgName = '', fgFull = false;
function startNow() {
  if (process.platform !== 'win32') return;
  nowP = spawn('powershell', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', Buffer.from(SMTC, 'utf16le').toString('base64')], { windowsHide: true });
  let buf = ''; nowP.stdout.setEncoding('utf8');
  nowP.stdout.on('data', d => {
    buf += d; const ls = buf.split(/\r?\n/); buf = ls.pop();
    for (const l of ls) { try { const j = JSON.parse(l); fgName = (j.fg || '').toLowerCase(); fgFull = !!j.full; if (!j.title) { np = {}; continue; } j.key = j.title + '|' + j.artist; if (!j.cover && np.key === j.key) j.cover = np.cover; np = j; } catch {} }
  });
  nowP.on('exit', () => setTimeout(startNow, 5000));
}
const sent = {};
ipcMain.handle('now', e => { const o = { ...np }, id = e.sender.id; if (np.key && np.key === sent[id]) delete o.cover; else sent[id] = np.key || ''; return o; });
// ---- текст песни: загружается на вашем ПК из открытого сервиса LRCLIB
const lyc = {};
ipcMain.handle('lyrics', async (_, q) => {
  const k = q.artist + '|' + q.title; if (k in lyc) return lyc[k];
  let r = null;
  try {
    const u = new URL('https://lrclib.net/api/search'); u.search = new URLSearchParams({ track_name: q.title, artist_name: q.artist });
    const a = await (await fetch(u, { headers: { 'User-Agent': 'Skach/1.0' } })).json();
    const s = (a || []).filter(x => x.syncedLyrics).sort((x, y) => Math.abs(x.duration - q.dur) - Math.abs(y.duration - q.dur))[0], pl = (a || []).find(x => x.plainLyrics);
    if (s) r = { synced: true, lines: s.syncedLyrics.split('\n').map(l => { const m = l.match(/^\[(\d+):(\d+(?:\.\d+)?)\]\s*(.*)$/); return m ? { t: +m[1] * 60 + +m[2], s: m[3] } : null; }).filter(Boolean) };
    else if (pl) r = { synced: false, lines: pl.plainLyrics.split('\n').map(s => ({ t: 0, s })) };
  } catch {}
  lyc[k] = r; const ks = Object.keys(lyc); if (ks.length > 30) delete lyc[ks[0]]; return r;
});
// ---- нагрузка и FPS
let prev = os.cpus(), apps = {}, pm;
const cpu = () => { const c = os.cpus(); let i = 0, t = 0; c.forEach((x, k) => { const a = x.times, b = prev[k].times, s = q => q.user + q.nice + q.sys + q.idle + q.irq; t += s(a) - s(b); i += a.idle - b.idle; }); prev = c; return t ? Math.round(100 * (1 - i / t)) : 0; };
const SKIP = /^(dwm|explorer|skach|electron|searchhost|shellexperiencehost|applicationframehost|textinputhost|startmenuexperiencehost|chrome|msedge|msedgewebview2|firefox|opera|brave|discord|spotify|yandexmusic|telegram|steamwebhelper|code|cursor|widgets|taskmgr|vlc|potplayer|potplayermini|potplayermini64|mpc-hc|mpc-hc64|mpv|wmplayer|kmplayer|obs64|zoom|teams|slack|whatsapp|vivaldi|browser|yandex|vmware|mstsc)\.exe$/i;
function fps() {
  if (cfg.fps === false || !fgFull) return null;
  const now = Date.now(); let pick = null;
  for (const [n, o] of Object.entries(apps)) {
    const f = o.f.filter(x => now - x.t < 5000);
    if (now - o.t > 2500 || f.length < 20 || SKIP.test(n)) continue;
    const fg = n.toLowerCase().replace(/\.exe$/, '') === fgName ? 1 : 0; if (!fg) continue;
    if (!pick || fg > pick.fg || (fg === pick.fg && f.length > pick.f.length)) pick = { n, f, fg };
  }
  if (!pick) return null;
  const last = pick.f.filter(x => now - x.t < 1000), s = pick.f.map(x => x.ms).sort((a, b) => b - a);
  return { app: pick.n.replace(/\.exe$/i, ''), fps: last.length, low: Math.round(1000 / s[Math.floor(s.length * .01)]), ms: Math.round(10 * last.reduce((a, b) => a + b.ms, 0) / Math.max(last.length, 1)) / 10 };
}
const pmDir = () => path.join(app.getPath('userData'), 'PresentMon.exe');
const pmExe = () => [path.join(process.resourcesPath || '', 'PresentMon.exe'), path.join(__dirname, 'extra', 'PresentMon.exe'), pmDir()].find(fs.existsSync);
let pmStop = false;
function stopPM() { pmStop = true; try { pm && pm.kill(); } catch {} pm = null; apps = {}; }
function startPM() { // PresentMon (Intel, MIT) читает кадры любой игры; положите PresentMon.exe в папку extra/
  if (pm) return; pmStop = false;
  const exe = pmExe();
  if (!exe) return;
  const run = a => {
    pm = spawn(exe, a, { windowsHide: true }); let buf = '', ix = null;
    pm.stdout.on('data', d => {
      buf += d; const ls = buf.split(/\r?\n/); buf = ls.pop();
      for (const l of ls) {
        const c = l.split(',');
        if (!ix) { const h = l.toLowerCase().split(','); ix = { a: h.indexOf('application'), m: h.findIndex(x => x === 'msbetweenpresents' || x === 'frametime') }; continue; }
        const ms = parseFloat(c[ix.m]);
        if (ms > 0) { const o = apps[c[ix.a]] || (apps[c[ix.a]] = { f: [], t: 0 }), n = Date.now(); o.f.push({ t: n, ms }); while (o.f.length && n - o.f[0].t > 6000) o.f.shift(); o.t = n; }
      }
    });
    const me = pm; pm.on('exit', code => { if (pm === me) pm = null; if (!pmStop && code && a[0].startsWith('--')) run(['-output_stdout', '-stop_existing_session']); });
  };
  run(['--output_stdout', '--stop_existing_session']);
}
ipcMain.handle('stats', () => new Promise(r => {
  const s = { cpu: cpu(), ram: Math.round(100 * (1 - os.freemem() / os.totalmem())), tot: os.totalmem(), fr: os.freemem(), fps: fps() };
  execFile('nvidia-smi', ['--query-gpu=utilization.gpu,temperature.gpu', '--format=csv,noheader,nounits'], { windowsHide: true, timeout: 2000 }, (e, o) => {
    if (!e && o) { const [g, t] = o.trim().split(/,\s*/); s.gpu = +g; s.temp = +t; } r(s);
  });
}));
// ---- ИИ: бесплатный (Pollinations, без ключа) или Anthropic, если ключ указан в настройках
ipcMain.handle('fpsState', () => new Promise(r => execFile('net', ['session'], { windowsHide: true }, e => r({ pm: !!pmExe(), admin: !e, running: !!pm }))));
ipcMain.handle('fpsInstall', async () => {
  try {
    const rel = await (await fetch('https://api.github.com/repos/GameTechDev/PresentMon/releases/latest', { headers: { 'User-Agent': 'Skach' } })).json();
    const a = (rel.assets || []).find(x => /PresentMon.*x64\.exe$/i.test(x.name) && !/setup|install/i.test(x.name));
    if (!a) return 'Не нашёл файл PresentMon на GitHub. Скачайте вручную (см. README).';
    fs.writeFileSync(pmDir(), Buffer.from(await (await fetch(a.browser_download_url)).arrayBuffer())); startPM(); return 'ok';
  } catch (e) { return 'Не удалось скачать: ' + e.message; }
});
ipcMain.handle('asAdmin', () => { const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath; execFile('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', `Start-Process -FilePath '${exe}' -Verb RunAs`], { windowsHide: true }); setTimeout(() => app.exit(0), 500); });
// ---- погода (Open-Meteo, без ключа; город по IP или из настроек)
let wx = null, wxAt = 0;
const WC = c => c === 0 ? ['☀️', 'Ясно'] : c <= 2 ? ['⛅', 'Переменная облачность'] : c === 3 ? ['☁️', 'Пасмурно'] : c <= 48 ? ['🌫️', 'Туман'] : c <= 57 ? ['🌦️', 'Морось'] : c <= 67 ? ['🌧️', 'Дождь'] : c <= 77 ? ['❄️', 'Снег'] : c <= 82 ? ['🌧️', 'Ливень'] : c <= 86 ? ['🌨️', 'Снегопад'] : ['⛈️', 'Гроза'];
ipcMain.handle('weather', async () => {
  if (wx && Date.now() - wxAt < 9e5) return wx;
  try {
    let la, lo, city = cfg.city;
    if (city) { const g = (await (await fetch('https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&name=' + encodeURIComponent(city))).json()).results?.[0]; if (g) { la = g.latitude; lo = g.longitude; city = g.name; } else return { err: 'город «' + city + '» не найден' }; }
    if (la == null) { const j = await (await fetch('https://ipwho.is/')).json(); la = j.latitude; lo = j.longitude; city = j.city; }
    const w = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${la}&longitude=${lo}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5&wind_speed_unit=ms`)).json();
    const c = w.current;
    wx = { city, t: Math.round(c.temperature_2m), f: Math.round(c.apparent_temperature), h: c.relative_humidity_2m, w: Math.round(c.wind_speed_10m), c: WC(c.weather_code), days: w.daily.time.map((d, i) => ({ d, hi: Math.round(w.daily.temperature_2m_max[i]), lo: Math.round(w.daily.temperature_2m_min[i]), c: WC(w.daily.weather_code[i])[0] })) };
    wxAt = Date.now(); return wx;
  } catch (e) { return { err: e.message }; }
});
// ---- буфер обмена (только в памяти, на диск не пишется)
let clips = [], lastClip = '';
setInterval(() => { try { const t = clipboard.readText(); if (t && t !== lastClip) { lastClip = t; const old = clips.find(c => c.t === t); clips = clips.filter(c => c.t !== t); clips.unshift({ t, pin: !!(old && old.pin) }); const un = clips.filter(c => !c.pin); if (un.length > 30) clips = clips.filter(c => c.pin || un.indexOf(c) < 30); } } catch {} }, 800);
ipcMain.handle('clips', () => clips.slice().sort((a, b) => b.pin - a.pin));
ipcMain.handle('clipCopy', (_, t) => { lastClip = t; clipboard.writeText(t); });
ipcMain.handle('clipDel', (_, t) => { clips = clips.filter(c => c.t !== t); });
ipcMain.handle('clipPin', (_, t) => { const c = clips.find(x => x.t === t); if (c) c.pin = !c.pin; });
ipcMain.handle('clipClear', () => { clips = clips.filter(c => c.pin); });
// ---- система
const SYS = { lock: ['rundll32.exe', ['user32.dll,LockWorkStation']], sleep: ['rundll32.exe', ['powrprof.dll,SetSuspendState', '0,1,0']], restart: ['shutdown', ['/r', '/t', '5']], off: ['shutdown', ['/s', '/t', '5']] };
ipcMain.handle('sys', (_, a) => { if (process.platform === 'win32' && SYS[a]) execFile(SYS[a][0], SYS[a][1], { windowsHide: true }, () => {}); });
ipcMain.handle('open', (_, u) => /^ms-settings:[a-z-]+$/.test(u) ? shell.openExternal(u) : null);
ipcMain.handle('ignore', (e, b) => BrowserWindow.fromWebContents(e.sender)?.setIgnoreMouseEvents(!!b, { forward: true }));
ipcMain.handle('get', () => cfg);
ipcMain.handle('set', (_, p) => { Object.assign(cfg, p); if ('pos' in p) { cfg.cx = null; cfg.cy = null; } save(); if ('city' in p) wxAt = 0; if ('fps' in p) { p.fps ? startPM() : stopPM(); } if ('top' in p) win.setAlwaysOnTop(!!p.top, p.top ? 'screen-saver' : 'normal'); if ('autostart' in p) app.setLoginItemSettings({ openAtLogin: !!p.autostart }); if ('pos' in p) place(); if (ww) ww.webContents.send('wcfg', cfg); if ('wtop' in p && ww) ww.setAlwaysOnTop(!!p.wtop, p.wtop ? 'screen-saver' : 'normal'); if ('whide' in p && ww) { p.whide ? ww.hide() : ww.showInactive(); } });
ipcMain.handle('size', (_, b) => { big = !!b; place(); if (big) { win.show(); win.focus(); } });
ipcMain.handle('shortcut', () => {
  try {
    const o = { target: process.env.PORTABLE_EXECUTABLE_FILE || process.execPath, icon: process.env.PORTABLE_EXECUTABLE_FILE || process.execPath, iconIndex: 0, description: 'Skach', appUserModelId: 'app.skach' };
    const d = shell.writeShortcutLink(path.join(app.getPath('desktop'), 'Skach.lnk'), 'create', o);
    const m = shell.writeShortcutLink(path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Skach.lnk'), 'create', o);
    return d && m;
  } catch { return false; }
});
let drag = null;
ipcMain.on('dragStart', () => { drag = win.getBounds(); });
ipcMain.on('dragMove', (_, dx, dy) => { if (drag) win.setBounds({ x: Math.round(drag.x + dx), y: Math.round(drag.y + dy), width: drag.width, height: drag.height }); });
ipcMain.on('dragEnd', () => { if (!drag) return; const b = win.getBounds(); cfg.cx = b.x + b.width / 2; cfg.cy = b.y; save(); drag = null; });
ipcMain.handle('resetPos', () => { cfg.cx = null; cfg.cy = null; save(); place(); });
// ---- виджеты на рабочем столе: один прозрачный слой, пока есть хотя бы один виджет
let ww = null;
const WT = ['music', 'clock', 'weather', 'cal', 'sys', 'mem'], PRE = { day: ['clock', 'weather', 'cal', 'music'], pc: ['sys', 'mem'], work: ['cal', 'clock', 'music'] };
const wid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
function ensureW() {
  if (!Array.isArray(cfg.widgets)) cfg.widgets = [];
  if (!cfg.widgets.length) { if (ww) { ww.destroy(); ww = null; } return; }
  if (ww) { ww.webContents.send('wcfg', cfg); return; }
  const a = screen.getPrimaryDisplay().workArea;
  ww = new BrowserWindow({ x: a.x, y: a.y, width: a.width, height: a.height, frame: false, transparent: true, resizable: false, skipTaskbar: true, focusable: false, hasShadow: false, show: !cfg.whide, alwaysOnTop: !!cfg.wtop, webPreferences: { preload: path.join(__dirname, 'preload.js'), spellcheck: false } });
  ww.setIgnoreMouseEvents(true, { forward: true });
  if (cfg.wtop) ww.setAlwaysOnTop(true, 'screen-saver');
  ww.loadFile('widgets.html'); ww.on('closed', () => { ww = null; });
}
ipcMain.handle('wAdd', (_, t) => { if (!WT.includes(t)) return; const n = cfg.widgets.length % 8; cfg.widgets.push({ id: wid(), t, x: 80 + 30 * n, y: 120 + 30 * n, s: 0 }); save(); ensureW(); });
ipcMain.handle('wPreset', (_, k) => { if (!PRE[k]) return; cfg.widgets = PRE[k].map((t, i) => ({ id: wid(), t, x: 60 + i * 215, y: 120, s: 0 })); save(); ensureW(); });
ipcMain.handle('wClear', () => { cfg.widgets = []; save(); ensureW(); });
ipcMain.on('wSave', (_, l) => { if (!Array.isArray(l)) return; cfg.widgets = l.filter(w => WT.includes(w.t)).map(w => ({ id: String(w.id), t: w.t, x: +w.x || 0, y: +w.y || 0, s: +w.s || 0 })); save(); if (!cfg.widgets.length) ensureW(); });
// ---- умный очиститель памяти (по запросу, без постоянных процессов)
const SYSP = /^(system|idle|registry|smss|csrss|wininit|winlogon|services|lsass|svchost|dwm|explorer|fontdrvhost|sihost|ctfmon|runtimebroker|searchhost|startmenuexperiencehost|shellexperiencehost|textinputhost|securityhealth\w*|msmpeng|nissrv|memcompression|audiodg|spoolsv|wudfhost|conhost|taskhostw|dllhost|powershell|skach|electron|taskmgr)$/i;
const SAFE = /^(ms-teams|teams|discord|spotify|steam|steamwebhelper|onedrive|skype|slack|zoom|telegram|whatsapp|viber|epicgameslauncher|battle\.net|origin|ubisoftconnect|upc|ccxprocess|creative cloud.*|adobe.*|dropbox|googledrivefs|yandexdisk|chrome|msedge|firefox|opera|browser|code|cursor|idea64|postman)$/i;
const PSL = c => new Promise(r => execFile('powershell', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', c], { windowsHide: true, timeout: 25000 }, (e, o) => r(o || '')));
ipcMain.handle('memScan', async () => {
  const o = await PSL("Get-Process | Group-Object ProcessName | ForEach-Object { [pscustomobject]@{n=$_.Name;c=$_.Count;mb=[math]::Round(($_.Group | Measure-Object WorkingSet64 -Sum).Sum/1MB)} } | Sort-Object mb -Descending | Select-Object -First 14 | ConvertTo-Json -Compress");
  let l = []; try { l = [].concat(JSON.parse(o)); } catch {}
  return { tot: os.totalmem(), fr: os.freemem(), list: l.map(x => ({ n: String(x.n), c: x.c, mb: x.mb, k: SYSP.test(x.n) ? 'sys' : SAFE.test(x.n) ? 'safe' : 'mid' })) };
});
ipcMain.handle('memKill', async (_, n) => { if (!/^[\w .+-]{1,60}$/.test(n) || SYSP.test(n)) return false; await PSL(`Stop-Process -Name '${n}' -Force -ErrorAction SilentlyContinue`); return true; });
ipcMain.handle('memTrim', async () => { const b = os.freemem(); await PSL("Add-Type -MemberDefinition '[DllImport(\"psapi.dll\")]public static extern bool EmptyWorkingSet(IntPtr h);' -Name P -Namespace M; Get-Process | ForEach-Object { try { [void][M.P]::EmptyWorkingSet($_.Handle) } catch {} }"); await new Promise(r => setTimeout(r, 800)); return os.freemem() - b; });
ipcMain.handle('quit', () => app.quit());
app.whenReady().then(() => {
  try { cfg = { ...DEF, ...JSON.parse(fs.readFileSync(cp(), 'utf8')) }; } catch {}
  win = new BrowserWindow({ width: 280, height: 48, frame: false, transparent: true, alwaysOnTop: true, skipTaskbar: false, resizable: false, hasShadow: false,
    icon: path.join(__dirname, 'build', 'icon.png'), webPreferences: { preload: path.join(__dirname, 'preload.js'), spellcheck: false, webviewTag: true } });
  win.setAlwaysOnTop(cfg.top !== false, cfg.top !== false ? 'screen-saver' : 'normal'); session.defaultSession.setDisplayMediaRequestHandler((req, cb) => { desktopCapturer.getSources({ types: ['screen'] }).then(s => cb({ video: s[0], audio: 'loopback' })).catch(() => cb({})); });
  win.webContents.on('did-finish-load', () => win.webContents.executeJavaScript('initAudio()', true).catch(() => {}));
  win.loadFile('index.html'); place(); if (cfg.fps !== false) startPM(); startNow(); win.on('blur', () => win.webContents.send('blur')); ensureW();
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png')).resize({ width: 16, height: 16 }));
  tray.setToolTip('Skach');
  tray.setContextMenu(Menu.buildFromTemplate([{ label: 'Раскрыть остров', click: () => win.webContents.send('toggle') }, { label: 'Выйти', click: () => app.quit() }]));
  tray.on('click', () => win.webContents.send('toggle'));
  globalShortcut.register('Control+Alt+S', () => win.webContents.send('toggle'));
});
app.on('window-all-closed', () => app.quit());

app.on('will-quit', () => { try { nowP && nowP.kill(); } catch {} });
